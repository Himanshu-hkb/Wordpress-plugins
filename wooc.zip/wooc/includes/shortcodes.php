<?php

add_shortcode('wpcarousel', 'wpcarousel_output');

function wpcarousel_output($atts) {
    $atts = shortcode_atts(array(
        'category' => '' // Optional category filter
    ), $atts, 'wpcarousel');

    ob_start();
    ?>

    <div class="wpcarousel-wrapper">
        <div class="wpcarousel-slider">
            <?php
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => 12,
            );

            if (!empty($atts['category'])) {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'product_cat',
                        'field'    => 'slug',
                        'terms'    => sanitize_text_field($atts['category']),
                    ),
                );
            }

            $loop = new WP_Query($args);

            if ($loop->have_posts()) :
                while ($loop->have_posts()) : $loop->the_post();
                    global $product;

                    $product_name = get_the_title();
                    $encoded_message = urlencode("Hi, I am interested in \"$product_name\" cake and want to place an order.");
                    $whatsapp_link = "https://wa.me/919891006180?text=" . $encoded_message;
            ?>
            
            <div class="wpcarousel-card">
                
                <div class="wpcarousel-img">
                    <?php echo $product->get_image(); ?>
                </div>

                <h3 class="wpcarousel-title"><?php echo esc_html($product_name); ?></h3>

                <div class="wpcarousel-price-rating">
                    <span class="price"><?php echo $product->get_price_html(); ?></span>
                    <span class="rating"><?php echo wc_get_rating_html($product->get_average_rating()); ?></span>
                </div>

                <!-- WhatsApp + Call Buttons -->
                <div class="wpcarousel-contact-buttons">
    <a href="<?php echo esc_url($whatsapp_link); ?>" target="_blank" class="wpcarousel-whatsapp" title="Chat on WhatsApp">
        <i class="fa fa-whatsapp"></i>
    </a>
    <a href="tel:+919891006180" class="wpcarousel-call" title="Call Now">
        <i class="fa fa-phone"></i>
    </a>
</div>

                <!-- Buy Now Button -->
                <a href="<?php echo get_permalink($product->get_id()); ?>" class="button">
                    Buy Now
                </a>

            </div>

            <?php 
                endwhile;
                wp_reset_postdata();
            else :
                echo '<p>No products found</p>';
            endif;
            ?>
        </div>
    </div>

    <?php
    return ob_get_clean();
}