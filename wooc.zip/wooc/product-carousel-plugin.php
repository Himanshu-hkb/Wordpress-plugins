<?php
/**
 * Plugin Name: Woo Product Carousel
 * Description: Carousel display of WooCommerce products with auto-scroll and category filter.
 * Version: 1.1
 * Author: Himanshu Kumar
 * Author URI: https://himanshuweb.com
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WPCAROUSEL_DIR', plugin_dir_path( __FILE__ ) );

add_action('wp_enqueue_scripts', 'wpcarousel_enqueue_assets');
function wpcarousel_enqueue_assets() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css');
    wp_enqueue_style('wpcarousel-style', plugin_dir_url(__FILE__) . 'assets/style.css');
    wp_enqueue_script('slick-carousel', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), null, true);
    wp_enqueue_style('slick-style', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
    wp_enqueue_style('slick-theme', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css');
    wp_enqueue_script('wpcarousel-script', plugin_dir_url(__FILE__) . 'assets/script.js', array('jquery'), null, true);
}

require_once WPCAROUSEL_DIR . 'includes/shortcodes.php';
